# HOW TO?

# 1. npm init 을 통해 package.json 생성 
	## → 
PS D:\200. 워크스페이스\learnReact\webpack-test> npm init
 ...
package name: (webpack-test) webpack-testing
 ... 
About to write to D:\200. 워크스페이스\learnReact\webpack-test\package.json:

{
  "name": "webpack-testing",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC"
}


# 2. react, react-dom 설치
	## → 
PS D:\200. 워크스페이스\learnReact\webpack-test> npm i react react-dom
{
  "name": "webpack-testing",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {  ## ⭐디펜던시 부분에 설치된 것을 확인 
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  }
}


# 3. webpack, webpack-cli 설치
	## → 개발할때만 webpack이 필요하기 때문에 -D 옵션 
PS D:\200. 워크스페이스\learnReact\webpack-test> npm i -D webpack webpack-cli
{
  "name": "webpack-testing",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {  ## ⭐개발용 디펜던시 부분에 설치된 것을 확인
    "webpack": "^5.86.0",
    "webpack-cli": "^5.1.4"
  }
}

# 4. webpack 설정파일, client.jsx, index.html 추가
PS D:\200. 워크스페이스\learnReact\webpack-test> echo "module.exports = {};" > webpack.config.js
PS D:\200. 워크스페이스\learnReact\webpack-test> echo "const React = require('react'); const ReactDom = require('react-dom');" > client.jsx
PS D:\200. 워크스페이스\learnReact\webpack-test> echo "<html></html>" > index.html
